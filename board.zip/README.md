# Board

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.1.1.

angular와 간단한 API를 이용하여 HTTP 통신을 이용한 게시판 제작

## 사용한 것들
angular6+

angular-redux

redux-observable

redux-logger

