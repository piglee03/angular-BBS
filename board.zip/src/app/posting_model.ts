export interface Posting {
  id: Number;
  title: String;
  text: String;
}
